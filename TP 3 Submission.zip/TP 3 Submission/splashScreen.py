try: from cmu_cs3_graphics import *
except: from cmu_graphics import *

from runAppWithScreens import *

##################################
# Splash Screen
##################################

def splashScreen_onScreenStart(app):
    app.font = 'helvetica'

def splashScreen_onKeyPress(app, key):
    if key == 'p': 
        setActiveScreen('playScreen')
    elif key == 'h':
        setActiveScreen('helpScreen')

def splashScreen_onMousePress(app, mouseX, mouseY):
    print(mouseX, mouseY)

def splashScreen_redrawAll(app):
    drawLabel('SUDOKU', app.width/2, app.height/2, size=300, bold=True, font=app.font)
    drawLabel("Press 'p' to play", app.width/2, 600, size=20, bold=True)
