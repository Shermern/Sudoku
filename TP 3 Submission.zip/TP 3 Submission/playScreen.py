try: from cmu_cs3_graphics import *
except: from cmu_graphics import *
import math
import os
import random
import copy
import itertools
import numpy as np
import cv2
import pyautogui
from fpdf import FPDF

from runAppWithScreens import *

##################################
# Play Screen
##################################

def playScreen_onScreenStart(app):
    app.width = 1400
    app.height = 900
    #######BOARD########
    app.rows = 9
    app.cols = 9
    app.boardWidth = app.height*0.8
    app.boardHeight = app.boardWidth
    app.boardLeft = app.width/2 - app.boardWidth/2 - 200
    app.boardTop = 100
    app.cellBorderWidth = 1
    app.fontColor = 'black'
    app.font = 'helvetica'
    app.hoverCell = None
    #######KEY PAD ########
    app.keyPadLeft = 1000
    app.keyPadTop = 200
    app.keyPadRows = 4
    app.keyPadCols = 3
    app.keyPadWidth = 240
    app.keyPadHeight = 320
    app.hoverNumberKey = None
    ########LEVELS#########
    app.levelsLeft = 875
    app.levelsTop = 50
    app.levelsRows = 1
    app.levelsCols = 6
    app.levelsWidth = 500
    app.levelsHeight = 50
    app.hoverLevels = None
    #########MODE OF PLAY########
    app.modeLeft = 875
    app.modeTop = 110
    app.modeRows = 1
    app.modeCols = 6
    app.modeWidth = 500
    app.modeHeight = 50
    app.hoverMode = None
    #########HINTS###########
    app.hintLeft = 1260
    app.hintTop = 250
    app.hintRows = 4
    app.hintCols = 1
    app.hintWidth = 120
    app.hintHeight = 200
    app.hoverHint = None
    #########LEGALS#######
    app.hoverLegals = None
    #########IMAGES##########
    app.url = 'controls.jpg'
    ######## OTHERS ########
    app.stepsPerSecond = 1
    ####RESET#####
    reset(app, filters=None)
    
def reset(app, filters=None):
    app.timer = 0
    app.takeFinalShot = True
    app.takeInitialShot = True
    legals = [[{i for i in range(1, 10)} for i in range(9)] for i in range(9)]
    app.loadBoard = loadRandomBoard(filters)
    app.currentState = 0
    app.history = [State(setBoardNums(app), copy.deepcopy(legals))]
    app.boardState = app.history[app.currentState]
    app.initialState = State(setBoardNums(app), copy.deepcopy(legals))
    app.selection = None
    app.boardState.print()
    app.levelSelected = str(filters)
    app.autoCandidate = False if 'easy' in app.loadBoard else True
    app.notes = False
    app.keyboardMode = False
    app.mouseMode = False
    app.standardMode = True
    app.manualMode = False
    app.helpScreen = False
    app.playerLegals = [[set(range(1, 10)) for col in range(app.cols)] for row in range(app.rows)]
    app.haveSingletons = True
    app.manualBoard = [[0 for col in range(app.cols)] for row in range(app.rows)]
    app.hint = set()
    app.solved = solver(app.boardState)
    app.contest = False
    app.savedAsPDF = False

############# STATE CLASS ######################
#from Sudoku Hints on 112-3 Website: https://www.cs.cmu.edu/~112-3/notes/tp-sudoku-hints.html
class State():
    def __init__(self, board, legals):
        self.rows = len(board)
        self.cols = len(board[0])
        self.blockSize = int(self.rows**0.5)
        self.board = board
        self.legals = legals
        self.isInitialVal = [[False for col in range(self.cols)] for row in range(self.rows)]
        self.illegals = dict()
        

        #set Initial Values
        for row in range(self.rows):
            for col in range(self.cols):
                value = self.board[row][col]
                if value != 0 and self.isInitialVal[row][col] != True:
                    self.isInitialVal[row][col] = True
                    self.legals[row][col] = set()
                    for banRow, banCol in self.getCellRegions(row, col):
                        self.ban(banRow, banCol, {value})
                        

        self.previousLegals = copy.deepcopy(self.legals)

    def isSolved(self):
        for row in range(self.rows):
            if 0 in self.board[row]:
                return False
        return True
        
    def set(self, row, col, value):
        initialVal = self.board[row][col]
        if initialVal == 0:
            self.previousLegals = copy.deepcopy(self.legals)
            self.board[row][col] = value
            self.legals[row][col] = set()
            for banRow, banCol in self.getCellRegions(row, col):
                self.ban(banRow, banCol, {value})
        elif initialVal != 0:
            self.legals = copy.deepcopy(self.previousLegals)
            self.board[row][col] = value
            self.legals[row][col] = set()
            for banRow, banCol in self.getCellRegions(row, col):
                self.ban(banRow, banCol, {value})
            
    def ban(self, row, col, values):
        for value in values:
            if value in self.legals[row][col]:
                self.legals[row][col].remove(value)

    def clearCell(self, row, col):
        if self.board[row][col] != 0:
            self.legals = copy.deepcopy(self.previousLegals)
            self.board[row][col] = 0
        
    def getRowRegion(self, row):
        region = []
        for col in range(self.cols):
            region.append((row, col))
        return region

    def getColRegion(self, col):
        region = []
        for row in range(self.rows):
            region.append((row, col))
        return region

    def getBlockRegion(self, block):
        region = []
        blockSize = self.blockSize
        blockStartRow = blockSize*(block//blockSize)
        blockStartCol = blockSize*(block%blockSize)
        for row in range(blockSize):
            for col in range(blockSize):
                targetRow = row + blockStartRow
                targetCol = col + blockStartCol
                region.append((targetRow, targetCol))
        return region

    def getBlock(self, row, col):
        block = (row//self.blockSize)*3 + col//self.blockSize
        return block
    
    def getBlockRegionByCell(self, row, col):
        block = self.getBlock(row, col)
        return self.getBlockRegion(block)
    
    def getCellRegions(self, row, col):
        regions = self.getRowRegion(row) + self.getColRegion(col) + self.getBlockRegionByCell(row, col)
        regions = list(set(regions))
        return regions
    
    def getAllRegions(self):
        allRegions = []
        for row in range(self.rows):
            allRegions.append(self.getRowRegion(row))
        for col in range(self.cols):
            allRegions.append(self.getColRegion(col))
        for block in range(self.rows):
            allRegions.append(self.getBlockRegion(block))
        return allRegions

    def getAllRegionsThatContainTargets(self, targets):
        targetRegions = set()
        for row, col in targets:
            cellRegions = set(self.getCellRegions(row, col))
            if targetRegions == set():
                targetRegions = cellRegions
            else:
                targetRegions = targetRegions & cellRegions
        return list(targetRegions)
                    
    def printLegals(self):
        colWidth = 4
        print('Legals')
        print('------')
        for col in range(9):
            colWidth = max(colWidth, 1+max([len(self.legals[row][col]) 
                           for row in range(9)]))
        for row in range(9):
            for col in range(9):
                label = ''.join([str(v) for v in sorted(self.legals[row][col])])
                if label == '': label = '-'
                print(f"{' '*(colWidth - len(label))}{label}", end='')
            print()
        print('-'*40)

    def printBoard(self):
        colWidth = 2
        print('Board')
        print('-----')
        for row in range(9):
            for col in range(9):
                label = ''.join(str(self.board[row][col]))
                if label == '': label = '-'
                print(f"{' '*(colWidth - len(label))}{label}", end='')
            print()
        print('-'*40)

    def printIsInitialVal(self):
        colWidth = 8
        print('isInitialValue')
        print('--------------')
        for row in range(9):
            for col in range(9):
                label = str(self.isInitialVal[row][col])
                if label == '': label = '-'
                print(f"{label}{' '*(colWidth - len(label))}", end='')
            print()
        print('-'*40)

    def print(self): 
        self.printBoard(); 
        self.printLegals()
  
############# DRAW BOARD #######################
def setBoardNums(app):
    board = [[] for row in range(app.rows)]
    contents = readFile(app.loadBoard)
    contents = contents.splitlines()
    for row in range(app.rows):
        for c in contents[row]:
            if c.isdigit():
                board[row].append(int(c))
    return board

def drawBoard(app):
    for row in range(app.rows): #draw cells
        for col in range(app.cols):
            drawCell(app, row, col)

def drawBoardBorder(app):
  # draw the board outline (with double-thickness):
  drawRect(app.boardLeft, app.boardTop, app.boardWidth, app.boardHeight,
           fill=None, border='black',
           borderWidth=4*app.cellBorderWidth)

def drawBlockBorder(app):
    for i in range(app.rows):
        blockSize = app.boardWidth/(app.rows)**0.5
        rectLeft = app.boardLeft + (i%3)*blockSize
        rectTop = app.boardTop + (i//3)*blockSize
        blockSize = app.boardWidth/(app.rows)**0.5
        drawRect(rectLeft, rectTop, blockSize, blockSize, fill=None, 
                border='black')

def drawCell(app, row, col):
    cellLeft, cellTop = getCellLeftTop(app, row, col)
    cellWidth, cellHeight = getCellSize(app)
    cellNum = str(app.boardState.board[row][col])
    numX = cellLeft + cellWidth/2
    numY = cellTop + cellHeight/2
    #fill grey if it is a set number
    setGrey = rgb(230, 230, 230)
    isSetNum = app.boardState.isInitialVal[row][col]
    cellColor = setGrey if isSetNum else None
    if (row, col) in app.hint:
        cellColor = 'lightgreen'
    drawRect(cellLeft, cellTop, cellWidth, cellHeight,
           fill=cellColor, border='black',
           borderWidth=app.cellBorderWidth)
    #draw transluscent cyan for selection
    selectColor = 'cyan'
    if (row, col) == app.selection:
        drawRect(cellLeft, cellTop, cellWidth, cellHeight,
                 fill=selectColor, border='black',
                 borderWidth=app.cellBorderWidth, opacity=100)
    if (row, col) == app.hoverCell:
        drawRect(cellLeft, cellTop, cellWidth, cellHeight,
                 fill=selectColor, border='black',
                 borderWidth=app.cellBorderWidth, opacity=20)

    if app.autoCandidate and app.boardState.board[row][col] == 0:
        drawLegals(app, cellLeft, cellTop, row, col, app.boardState.legals)
    
    elif app.boardState.board[row][col] == 0 and not app.autoCandidate:
        cellVal = app.solved.board[row][col]
        if cellVal not in app.playerLegals[row][col]:
            drawRect(cellLeft, cellTop, cellWidth, cellHeight, fill='pink', opacity = 50)
        drawLegals(app, cellLeft, cellTop, row, col, app.playerLegals)
        
    drawRect(cellLeft, cellTop, cellWidth, cellHeight,
           fill=None, border='black',
           borderWidth=app.cellBorderWidth)
    
    if cellNum != '0':
        drawLabel(cellNum, numX, numY, size=60, fill=app.fontColor, 
                  font=app.font, bold=False)
        if int(cellNum) != app.solved.board[row][col] and not app.contest and not app.manualMode:
            drawCircle(numX+25, numY+25, 5, fill='red')

def getCell(app, x, y):
    dx = x - app.boardLeft
    dy = y - app.boardTop
    cellWidth, cellHeight = getCellSize(app)
    row = math.floor(dy / cellHeight)
    col = math.floor(dx / cellWidth)
    if (0 <= row < app.rows) and (0 <= col < app.cols):
      return (row, col)
    else:
      return None

def getCellLeftTop(app, row, col):
    cellWidth, cellHeight = getCellSize(app)
    cellLeft = app.boardLeft + col * cellWidth
    cellTop = app.boardTop + row * cellHeight
    return (cellLeft, cellTop)

def getCellSize(app):
    cellWidth = app.boardWidth / app.cols
    cellHeight = app.boardHeight / app.rows
    return (cellWidth, cellHeight)

def drawBoardDifficulty(app):
    if app.levelSelected == 'None':
        levels = ['easy', 'medium', 'hard', 'expert', 'evil']
        for level in levels:
            if level in app.loadBoard:
                difficulty = level.upper()
    else:
        difficulty = app.levelSelected.upper()
    drawLabel(difficulty, app.boardLeft + app.boardWidth/2, app.boardTop - 25, size=50, bold=True, font=app.font)
####################### DRAW LEGALS #####################
def drawLegals(app, cellLeft, cellTop, cellRow, cellCol, legals):
    for row in range(3): #draw cells
        for col in range(3):
            drawLegalsCell(app, row, col, cellLeft, cellTop, cellRow, cellCol, legals)

def drawLegalsCell(app, row, col, cellLeft, cellTop, cellRow, cellCol, legals):
    legalsCellLeft, legalsCellTop = getLegalsCellLeftTop(app, row, col, cellLeft, cellTop)
    cellWidth, cellHeight = getLegalsCellSize(app)
    cellNum = str(getLegalsCellNum(app, row, col) + 1)
    numX = legalsCellLeft + cellWidth/2
    numY = legalsCellTop + cellHeight/2
    keyColor = None
    drawRect(legalsCellLeft, legalsCellTop, cellWidth, cellHeight,
           fill=keyColor, borderWidth=1, opacity=100)
    if 1 <= int(cellNum) <= 9:
        if (int(cellNum) not in legals[cellRow][cellCol] and app.hoverLegals == (row, col) and app.selection == (cellRow, cellCol)):
            drawLabel(cellNum, numX, numY, size=18, fill=rgb(200, 200, 200), 
                font=app.font)
        elif (int(cellNum) in legals[cellRow][cellCol]):
            drawLabel(cellNum, numX, numY, size=18, fill=rgb(180, 180, 180), 
                     font=app.font)

def getLegalsCell(app, x, y, cellLeft, cellTop):
    dx = x - cellLeft
    dy = y - cellTop
    cellWidth, cellHeight = getLegalsCellSize(app)
    row = math.floor(dy / cellHeight)
    col = math.floor(dx / cellWidth)
    if (0 <= row < 3) and (0 <= col < 3):
      return (row, col)
    else:
      return None

def getLegalsCellLeftTop(app, row, col, cellLeft, cellTop):
    cellWidth, cellHeight = getLegalsCellSize(app)
    legalsCellLeft = cellLeft + col * cellWidth
    legalsCellTop = cellTop + row * cellHeight
    return (legalsCellLeft, legalsCellTop)

def getLegalsCellSize(app):
    cellWidth, cellHeight = getCellSize(app)
    cellWidth /= 3
    cellHeight /= 3
    return (cellWidth, cellHeight)

def getLegalsCellNum(app, row, col):
    cellNum = (row%3)*3 + col%3
    return cellNum

def drawAutoCandidateSelector(app):
    drawRect(1000, 550, 20, 20, fill=None, border='black')
    drawLabel("Auto Candidate ('a')", 1030, 560, size=20, font=app.font, align='left')
    if app.autoCandidate:
        drawPolygon(980, 535, 1010, 568, 1010, 560, fill='orange')
        drawPolygon(1010, 568, 1010, 560, 1025, 545, fill='orange')

def getAutoCandidateCell(app, x, y):
    dx = x - 1000
    dy = y - 550
    cellWidth, cellHeight = 20, 20
    row = math.floor(dy / cellHeight)
    col = math.floor(dx / cellWidth)
    if (0 <= row < 1) and (0 <= col < 1):
      return (row, col)
    else:
      return None

def drawNotes(app):
    drawRect(1000, 600, 20, 20, fill=None, border='black')
    drawLabel("Notes ('n')", 1030, 610, size=20, font=app.font, align='left')
    if app.notes:
        drawPolygon(980, 585, 1010, 618, 1010, 610, fill='orange')
        drawPolygon(1010, 618, 1010, 610, 1025, 595, fill='orange')

def getNotesCell(app, x, y):
    dx = x - 1000
    dy = y - 600
    cellWidth, cellHeight = 20, 20
    row = math.floor(dy / cellHeight)
    col = math.floor(dx / cellWidth)
    if (0 <= row < 1) and (0 <= col < 1):
      return (row, col)
    else:
      return None

####################### DRAW NUMPAD ###################
def drawKeyPad(app):
    for row in range(app.keyPadRows): #draw cells
        for col in range(app.keyPadCols):
            drawKeyPadCell(app, row, col)

def drawKeyPadBorder(app):
  # draw the board outline (with double-thickness):
    drawRect(app.keyPadLeft, app.keyPadTop, app.keyPadWidth, app.keyPadWidth,
           fill=None, border='black',
           borderWidth=4*app.cellBorderWidth)
    drawRect(app.keyPadLeft, app.keyPadTop, app.keyPadWidth, app.keyPadHeight,
           fill=None, border='black',
           borderWidth=4*app.cellBorderWidth)

def drawKeyPadCell(app, row, col):
    cellLeft, cellTop = getKeyPadCellLeftTop(app, row, col)
    cellWidth, cellHeight = getKeyPadCellSize(app)
    cellNum = str(getKeyCellNum(app, row, col) + 1)
    numX = cellLeft + cellWidth/2
    numY = cellTop + cellHeight/2
    keyColor = 'cyan' if app.hoverNumberKey == (row, col) else None
    drawRect(cellLeft, cellTop, cellWidth, cellHeight,
           fill=keyColor, border='black',
           borderWidth=app.cellBorderWidth)
    if 1 <= int(cellNum) <= 9:
        drawLabel(cellNum, numX, numY, size=40, fill=app.fontColor, 
                font=app.font)

    if int(cellNum) == 10:
        drawLine(1020, 460, 1060, 500, fill='red', lineWidth=3)
        drawLine(1020, 500, 1060, 460, fill='red', lineWidth=3)

    if int(cellNum) == 11:
        drawLabel('undo', numX, numY, size=20, fill=app.fontColor, 
                font=app.font)

    if int(cellNum) == 12:
        drawLabel('redo', numX, numY, size=20, fill=app.fontColor, 
                font=app.font)

def getKeyPadCell(app, x, y):
    dx = x - app.keyPadLeft
    dy = y - app.keyPadTop
    cellWidth, cellHeight = getKeyPadCellSize(app)
    row = math.floor(dy / cellHeight)
    col = math.floor(dx / cellWidth)
    if (0 <= row < app.keyPadRows) and (0 <= col < app.keyPadCols):
      return (row, col)
    else:
      return None

def getKeyPadCellLeftTop(app, row, col):
    cellWidth, cellHeight = getKeyPadCellSize(app)
    cellLeft = app.keyPadLeft + col * cellWidth
    cellTop = app.keyPadTop + row * cellHeight
    return (cellLeft, cellTop)

def getKeyPadCellSize(app):
    cellWidth = app.keyPadWidth / app.keyPadCols
    cellHeight = app.keyPadHeight / app.keyPadRows
    return (cellWidth, cellHeight)

def getKeyCellNum(app, row, col):
    cellNum = (row%app.keyPadRows)*3 + col%app.keyPadCols
    return cellNum

################ LEVEL SELECTOR ##################
def drawLevels(app):
    drawLabel('LEVELS', app.levelsLeft + app.levelsWidth/2, 45, size=18, bold=True)
    for row in range(app.levelsRows): #draw cells
        for col in range(app.levelsCols):
            drawLevelsCell(app, row, col)

def drawLevelsBorder(app):
  # draw the board outline (with double-thickness):
    drawRect(app.levelsLeft, app.levelsTop, app.levelsWidth, app.levelsHeight,
           fill=None, border='black',
           borderWidth=4*app.cellBorderWidth)

def drawLevelsCell(app, row, col):
    cellLeft, cellTop = getLevelsCellLeftTop(app, row, col)
    cellWidth, cellHeight = getLevelsCellSize(app)
    cellNum = str(getLevelsCellNum(app, row, col) + 1)
    numX = cellLeft + cellWidth/2
    numY = cellTop + cellHeight/2
    levelIndex = {'easy':(0, 0), 'medium':(0, 1), 'hard':(0, 2), 'expert':(0, 3), 'evil':(0, 4), 'None':(0, 5)}
    levelSelected = levelIndex.get(app.levelSelected, None)
    if app.hoverLevels == (row, col) or levelSelected == (row, col):
        bold = True
    else:
        bold = False
    drawRect(cellLeft, cellTop, cellWidth, cellHeight,
           fill=None,
           borderWidth=app.cellBorderWidth)
    
    if int(cellNum) == 1:
        drawLabel('Easy', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

    elif int(cellNum) == 2:
        drawLabel('Medium', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

    elif int(cellNum) == 3:
        drawLabel('Hard', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

    elif int(cellNum) == 4:
        drawLabel('Expert', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

    elif int(cellNum) == 5:
        drawLabel('Evil', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)
    
    elif int(cellNum) == 6:
        drawLabel('Random', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

def getLevelsCell(app, x, y):
    dx = x - app.levelsLeft
    dy = y - app.levelsTop
    cellWidth, cellHeight = getLevelsCellSize(app)
    row = math.floor(dy / cellHeight)
    col = math.floor(dx / cellWidth)
    if (0 <= row < app.levelsRows) and (0 <= col < app.levelsCols):
      return (row, col)
    else:
      return None

def getLevelsCellLeftTop(app, row, col):
    cellWidth, cellHeight = getLevelsCellSize(app)
    cellLeft = app.levelsLeft + col * cellWidth
    cellTop = app.levelsTop + row * cellHeight
    return (cellLeft, cellTop)

def getLevelsCellSize(app):
    cellWidth = app.levelsWidth / app.levelsCols
    cellHeight = app.levelsHeight / app.levelsRows
    return (cellWidth, cellHeight)

def getLevelsCellNum(app, row, col):
    cellNum = (row%app.levelsRows)*3 + col%app.levelsCols
    return cellNum

################# PLAY MODE #######################
def drawModes(app):
    drawLabel('MODES', app.levelsLeft + app.levelsWidth/2, 110, size=18, bold=True)
    for row in range(app.modeRows): #draw cells
        for col in range(app.modeCols):
            drawModeCell(app, row, col)

def drawModesBorder(app):
  # draw the board outline (with double-thickness):
    drawRect(app.modeLeft, app.modeTop, app.modeWidth, app.modeHeight,
           fill=None, border='black',
           borderWidth=4*app.cellBorderWidth)

def drawModeCell(app, row, col):
    cellLeft, cellTop = getModeCellLeftTop(app, row, col)
    cellWidth, cellHeight = getModeCellSize(app)
    cellNum = str(getModeCellNum(app, row, col) + 1)
    numX = cellLeft + cellWidth/2
    numY = cellTop + cellHeight/2
    if app.standardMode: mode = 'standard'
    elif app.keyboardMode: mode = 'keyboard'
    elif app.mouseMode: mode='mouse'
    elif app.helpScreen: mode='help'
    elif app.manualMode: mode='manual'
    modeIndex = {'standard':(0, 0), 'keyboard':(0, 1), 'mouse':(0, 2), 'manual':(0, 3), 'help':(0, 4)}
    modeSelected = modeIndex.get(mode, None)
    if app.hoverMode == (row, col) or modeSelected == (row, col):
        bold = True
    else:
        bold = False
    drawRect(cellLeft, cellTop, cellWidth, cellHeight,
           fill=None,
           borderWidth=app.cellBorderWidth)
    
    if int(cellNum) == 1:
        drawLabel('Standard', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

    elif int(cellNum) == 2:
        drawLabel('Keyboard', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

    elif int(cellNum) == 3:
        drawLabel('Mouse', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

    elif int(cellNum) == 4:
        drawLabel('Manual', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

    elif int(cellNum) == 5:
        drawLabel('Help', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

    elif int(cellNum) == 6:
        drawLabel('Comp', numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold=bold)

def getModeCell(app, x, y):
    dx = x - app.modeLeft
    dy = y - app.modeTop
    cellWidth, cellHeight = getModeCellSize(app)
    row = math.floor(dy / cellHeight)
    col = math.floor(dx / cellWidth)
    if (0 <= row < app.modeRows) and (0 <= col < app.modeCols):
      return (row, col)
    else:
      return None

def getModeCellLeftTop(app, row, col):
    cellWidth, cellHeight = getModeCellSize(app)
    cellLeft = app.modeLeft + col * cellWidth
    cellTop = app.modeTop + row * cellHeight
    return (cellLeft, cellTop)

def getModeCellSize(app):
    cellWidth = app.modeWidth / app.modeCols
    cellHeight = app.modeHeight / app.modeRows
    return (cellWidth, cellHeight)

def getModeCellNum(app, row, col):
    cellNum = (row%app.modeRows)*3 + col%app.modeCols
    return cellNum

################# PLAY SINGLETONS ##################
def playSingletons(app):
    if app.levelSelected != 'easy':
        for row in range(app.rows):
            for col in range(app.cols):
                legals = list(app.boardState.legals[row][col])
                if len(legals) == 1:
                    app.boardState.set(row, col, legals[0])
                    app.selection = (row, col)
                    app.haveSingletons = True
                    return True
        app.haveSingletons = False
    return False

def drawHints(app):
    drawLabel('HINTS', app.hintLeft + app.hintWidth/2, 230, size=18, bold=True)
    for row in range(app.hintRows): #draw cells
        for col in range(app.hintCols):
            drawHintCell(app, row, col)

def drawHintsBorder(app):
  # draw the board outline (with double-thickness):
    drawRect(app.hintLeft, app.hintTop, app.hintWidth, app.hintHeight,
           fill=None, border='black',
           borderWidth=4*app.cellBorderWidth)

def drawHintCell(app, row, col):
    cellLeft, cellTop = getHintCellLeftTop(app, row, col)
    cellWidth, cellHeight = getHintCellSize(app)
    cellNum = str(getHintCellNum(app, row, col) + 1)
    numX = cellLeft + cellWidth/2
    numY = cellTop + cellHeight/2
    if app.hoverHint == (row, col):
        bold = True
    else:
        bold = False
    drawRect(cellLeft, cellTop, cellWidth, cellHeight, fill=None,
           borderWidth=app.cellBorderWidth)
    
    if int(cellNum) == 1:
        drawLabel("Singleton ('s')", numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold = bold)

    elif int(cellNum) == 2:
        drawLabel("All Singletons ('S')", numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold = bold)

    elif int(cellNum) == 3:
        drawLabel("Hint 1 ('h')", numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold = bold)

    elif int(cellNum) == 4:
        drawLabel("Hint 2 ('H')", numX, numY, size=16, fill=app.fontColor, 
                font=app.font, bold = bold)

def getHintCell(app, x, y):
    dx = x - app.hintLeft
    dy = y - app.hintTop
    cellWidth, cellHeight = getHintCellSize(app)
    row = math.floor(dy / cellHeight)
    col = math.floor(dx / cellWidth)
    if (0 <= row < app.hintRows) and (0 == col):
      return (row, col)
    else:
      return None

def getHintCellLeftTop(app, row, col):
    cellWidth, cellHeight = getHintCellSize(app)
    cellLeft = app.hintLeft + col * cellWidth
    cellTop = app.hintTop + row * cellHeight
    return (cellLeft, cellTop)

def getHintCellSize(app):
    cellWidth = app.hintWidth / app.hintCols
    cellHeight = app.hintHeight / app.hintRows
    return (cellWidth, cellHeight)

def getHintCellNum(app, row, col):
    cellNum = row
    return cellNum

################# CONTROLS ########################
# def drawControls(app):
#     width, height = 846*0.3, 504*0.3
#     drawImage(app.url, 1000, 650, width=width, height=height)

################# SOLVER ##########################
def solver(board):
    if board.isSolved():
        print('Solved')
        return board

    else:
        if getLeastLegals(board) != None:
            row, col =  getLeastLegals(board)
            targetSet = board.legals[row][col]
            newBoardState = copy.deepcopy(board)
            for legal in targetSet:
                newBoardState.set(row, col, legal)
                result = solver(newBoardState)
                if result != None:
                    return result
    return None

def getLeastLegals(board):
    for i in range(1, 10):
        for row in range(board.rows):
            for col in range(board.cols):
                if board.board[row][col] == 0 and board.legals[row][col] == set():
                    return None
        for row in range(board.rows):
            for col in range(board.cols):
                if len(board.legals[row][col]) == i:
                    return (row, col)
    return None

################## HINTS ########################
def hint1(app):
    for row in range(app.rows):
        for col in range(app.cols):
            if len(app.boardState.legals[row][col]) == 1:
                app.selection = (row, col)
                app.hint = []
                return True
    return False

def hint2(app):
    for i in range(2, 6):
        for region in app.boardState.getAllRegions():
            validRegion = []
            for row, col in region:
                if app.boardState.legals[row][col] != set():
                    validRegion.append((row, col))
            for tuple in itertools.combinations(validRegion, i):
                legals = set()
                for row, col in tuple:
                    legals = legals|app.boardState.legals[row][col]
                for v in itertools.combinations(range(1, 10), i):
                    if legals == set(v):
                        print(tuple)
                        app.hint = set(tuple)
                        return (set(tuple), legals)
    return None
                
################# CONTROLLERS #####################
def playScreen_onStep(app):
    if gameIsOver(app):
        app.selection = None
    app.timer += 1
    if app.timer%2 == 0:
        app.haveSingletons = True
        app.savedAsPDF = False
    takeFinalScreenShot(app)
    takeInitialScreenShot(app)

def playScreen_redrawAll(app):
    drawBoard(app)
    drawBoardBorder(app)
    drawBlockBorder(app)
    drawBoardDifficulty(app)
    if gameIsOver(app):
        drawLabel('Game Over!', 1130, 700, size=80)
        drawLabel("press 'p' to save this game to pdf!", 1130, 750, size=18)
    if app.mouseMode or app.standardMode or app.helpScreen or app.manualMode:
        drawKeyPad(app)
        drawKeyPadBorder(app)
    drawLevels(app)
    drawAutoCandidateSelector(app)
    drawNotes(app)
    drawModes(app)
    drawHints(app)
    if not app.haveSingletons and not gameIsOver(app):
        drawRect(0, 0, app.width, app.height, fill='white', opacity = 80)
        drawLabel('No More Singletons', app.width/2, app.height/2, size=100, bold=True)
    if app.savedAsPDF:
        drawRect(0, 0, app.width, app.height, fill='white', opacity = 80)
        drawLabel('Saved!', app.width/2, app.height/2, size=100, bold=True)
        

def gameIsOver(app):
    gameOver = True
    for row in range(app.rows):
        for col in range(app.cols):
            if app.boardState.board[row][col] == 0:
                gameOver = False
                break
    contents = ''
    if app.contest and gameOver:
        for row in range(app.rows):
            for col in range(app.cols):
                if contents != '' and col == 0:
                    contents += '\n'
                contents += str(app.boardState.board[row][col]) + ' '
        writeFile('1contestSubmit.txt', contents)
    return gameOver

def takeFinalScreenShot(app):
    if gameIsOver(app) and app.takeFinalShot:
        image = pyautogui.screenshot(region=(325, 100, 1490, 1680))
        image = cv2.cvtColor(np.array(image),cv2.COLOR_RGB2BGR)
        cv2.imwrite("boardSolutionImage.png", image)
        app.takeFinalShot = not app.takeFinalShot

def takeInitialScreenShot(app):
    if app.takeInitialShot:

        image = pyautogui.screenshot(region=(325, 100, 1490, 1680))
        image = cv2.cvtColor(np.array(image),cv2.COLOR_RGB2BGR)
        cv2.imwrite("boardImage.png", image)
        app.takeInitialShot = False
        app.selection = (0,0)

def playScreen_onKeyPress(app, key):
    if app.keyboardMode or app.standardMode or app.manualMode:
        if key.isdigit():
            if key != '0':
                if app.selection != None:
                    row, col = app.selection
                    if app.boardState.isInitialVal[row][col] == False:
                        if not app.notes:
                            newState = copy.deepcopy(app.boardState)
                            app.history = app.history[:app.currentState + 1]
                            app.history.append(newState)
                            app.currentState += 1
                            app.boardState = app.history[app.currentState]
                            app.boardState.set(row, col, int(key))
                        elif app.manualMode:
                            app.boardState.set(row, col, int(key))
                            
                        else:
                            if int(key) in app.playerLegals[row][col]:
                                app.playerLegals[row][col].remove(int(key))
                            else:
                                app.playerLegals[row][col].add(int(key))


        if key == 'up':
            if app.selection != None:
                row, col = app.selection
                row -= 1
                row %= app.rows
                col %= app.cols
                app.selection = (row, col)

        if key == 'down':
            if app.selection != None:
                row, col = app.selection
                row += 1
                row %= app.rows
                col %= app.cols
                app.selection = (row, col)

        if key == 'left':
            if app.selection != None:
                row, col = app.selection
                col -= 1
                row %= app.rows
                col %= app.cols
                app.selection = (row, col)

        if key == 'right':
            if app.selection != None:
                row, col = app.selection
                col += 1
                row %= app.rows
                col %= app.cols
                app.selection = (row, col)

        if key == 'backspace':
            if app.selection != None:
                row, col = app.selection
                newState = copy.deepcopy(app.boardState)
                app.history = app.history[:app.currentState + 1]
                app.history.append(newState)
                app.currentState += 1
                app.boardState = app.history[app.currentState]
                app.boardState.clearCell(row, col)

    if key == 'n':
        app.notes = not app.notes
        app.autoCandidate = False

    if key == 'a':
        app.autoCandidate = not app.autoCandidate
        app.notes = False

    if key == 'm': 
        setActiveScreen('splashScreen')
    
    if key == 's' and not app.contest:
        playSingletons(app)

    if key == 'S' and not app.contest:
        while playSingletons(app):
            pass

    if key == 'u':
        if app.currentState > 0:
            print(app.currentState)
            app.currentState -= 1
            app.boardState = app.history[app.currentState]
    if key == 'r':
        if app.currentState + 1 < len(app.history):
            app.currentState += 1
            app.boardState = app.history[app.currentState]
    if key == 'h' and not app.contest:
        if hint1(app):
            pass
        else:
            hint2(app)
    
    if key == 'H' and not app.contest:
        singleton = False
        for row in range(app.rows):
            for col in range(app.cols):
                legals = list(app.boardState.legals[row][col])
                if len(legals) == 1:
                    app.boardState.set(row, col, legals[0])
                    app.selection = (row, col)
                    singleton = True
                    return

        if not singleton and hint2(app) != None:
            tuple, legals = hint2(app)
            region = app.boardState.getAllRegionsThatContainTargets(tuple)
            print(region)
            for row, col in region:
                if (row, col) not in tuple:
                    app.boardState.ban(row, col, legals)
    if key == 'p' and not app.takeFinalShot and gameIsOver(app):
        createPDF(app)
        app.savedAsPDF = True

            
def playScreen_onMousePress(app, mouseX, mouseY):
    print(mouseX, mouseY)
    selectedCell = getCell(app, mouseX, mouseY)
    selectedNumberKey = getKeyPadCell(app, mouseX, mouseY)
    selectedLevel = getLevelsCell(app, mouseX, mouseY)
    autoCandidate = getAutoCandidateCell(app, mouseX, mouseY)
    notes = getNotesCell(app, mouseX, mouseY)
    selectedMode = getModeCell(app, mouseX, mouseY)
    selectedHint = getHintCell(app, mouseX, mouseY)

    if selectedHint != None:
        if selectedHint == (0, 0) and not app.contest:
            playSingletons(app)
        elif selectedHint == (1, 0) and not app.contest:
            while playSingletons(app):
                pass
        elif selectedHint == (2, 0) and not app.contest:
            if hint1(app):
                pass
            else:
                hint2(app)
        elif selectedHint == (3, 0) and not app.contest:
            singleton = False
            for row in range(app.rows):
                for col in range(app.cols):
                    legals = list(app.boardState.legals[row][col])
                    if len(legals) == 1:
                        app.boardState.set(row, col, legals[0])
                        app.selection = (row, col)
                        singleton = True
                        return
            if not singleton and hint2(app) != None:
                tuple, legals = hint2(app)
                region = app.boardState.getAllRegionsThatContainTargets(tuple)
                for row, col in region:
                    if (row, col) not in tuple:
                        app.boardState.ban(row, col, legals)

    if app.mouseMode or app.standardMode or app.manualMode:
        if selectedCell == app.selection:
            row, col = app.selection
            cellLeft, cellTop = getCellLeftTop(app, row, col)
            legals = getLegalsCell(app, mouseX, mouseY, cellLeft, cellTop)
            if legals != None and app.notes:
                legalRow, legalCol = legals
                value = getLegalsCellNum(app, legalRow, legalCol) + 1
                if value in app.playerLegals[row][col]:
                    app.playerLegals[row][col].remove(value)
                else:
                    app.playerLegals[row][col].add(value)
        
        if selectedCell != None:
            app.selection = selectedCell
            app.hint = set()

        elif (selectedNumberKey != None and app.selection != None):
            row, col = selectedNumberKey
            targetRow, targetCol = app.selection
            cellNum = getKeyCellNum(app, row, col)
            if 0 <= cellNum <= 8:
                if app.boardState.isInitialVal[targetRow][targetCol] == False:
                    value = getKeyCellNum(app, row, col) + 1
                    if not app.notes:
                            newState = copy.deepcopy(app.boardState)
                            app.history = app.history[:app.currentState + 1]
                            app.history.append(newState)
                            app.currentState += 1
                            app.boardState = app.history[app.currentState]
                            app.boardState.set(targetRow, targetCol, value)
                    elif app.manualMode:
                        app.boardState.set(targetRow, targetCol, value)

                    else:
                        if value in app.playerLegals[targetRow][targetCol]:
                            app.playerLegals[targetRow][targetCol].remove(value)
                        else:
                            app.playerLegals[targetRow][targetCol].add(value)

            elif cellNum == 9:
                if app.boardState.isInitialVal[targetRow][targetCol] == False:
                    if app.selection != None:
                        row, col = app.selection
                        newState = copy.deepcopy(app.boardState)
                        app.history = app.history[:app.currentState + 1]
                        app.history.append(newState)
                        app.currentState += 1
                        app.boardState = app.history[app.currentState]
                        app.boardState.clearCell(targetRow, targetCol)

            elif cellNum == 10:
                if app.currentState > 0:
                    app.currentState -= 1
                    app.boardState = app.history[app.currentState]

            elif cellNum == 11:
                if app.currentState + 1 < len(app.history):
                    app.currentState += 1
                    app.boardState = app.history[app.currentState]
        
    if selectedMode != None:
            row, col = selectedMode
            cellNum = getModeCellNum(app, row, col)
            if cellNum == 0:
                if app.manualMode:
                    app.boardState = State(copy.deepcopy(app.boardState.board), [[{i for i in range(1, 10)} for i in range(9)] for i in range(9)])
                    app.levelSelected = 'MANUAL'
                    app.autoCandidate = False
                    app.solved = solver(app.boardState)
                app.standardMode = True
                app.keyboardMode = False
                app.mouseMode = False
                app.helpScreen = False
                app.manualMode = False

            if cellNum == 1:
                app.standardMode = False
                app.keyboardMode = True
                app.mouseMode = False
                app.helpScreen = False
                app.manualMode = False

            if cellNum == 2:
                app.standardMode = False
                app.keyboardMode = False
                app.mouseMode = True
                app.helpScreen = False
                app.manualMode = False
            
            if cellNum == 3:
                if app.manualMode:
                    app.manualMode = False
                    app.standardMode = True
                    
                else:
                    app.standardMode = False
                    app.keyboardMode = False
                    app.mouseMode = False
                    app.helpScreen = False
                    app.manualMode = True
                
                app.levelSelected = 'MANUAL'
                app.boardState = State([[0 for col in range(app.cols)] for row in range(app.cols)], [[{i for i in range(1, 10)} for i in range(9)] for i in range(9)])
                app.autoCandidate = False


            if cellNum == 4:
                setActiveScreen('helpScreen')
                app.helpScreen = True

            if cellNum == 5:
                reset(app, 'contest')
                app.contest = True

    if notes != None:
            app.notes = not app.notes
            if app.notes:
                app.autoCandidate = False

    if autoCandidate != None:
        app.autoCandidate = not app.autoCandidate
        if app.autoCandidate:
            app.notes = False

    elif (selectedLevel != None):
        row, col = selectedLevel
        cellNum = getLevelsCellNum(app, row, col)
        if cellNum == 0:
            reset(app, 'easy')
        if cellNum == 1:
            reset(app, 'medium')
        if cellNum == 2:
            reset(app, 'hard')
        if cellNum == 3:
            reset(app, 'expert')
        if cellNum == 4:
            reset(app, 'evil')
        if cellNum == 5:
            reset(app)

def playScreen_onMouseMove(app, mouseX, mouseY):
    selectedNumberKey = getKeyPadCell(app, mouseX, mouseY)
    selectedLevel = getLevelsCell(app, mouseX, mouseY)
    selectedCell = getCell(app, mouseX, mouseY)
    selectedMode = getModeCell(app, mouseX, mouseY)
    selectedHint = getHintCell(app, mouseX, mouseY)

    if selectedHint != None:
        app.hoverHint = selectedHint
    else:
        app.hoverHint = None

    if app.mouseMode or app.standardMode or app.manualMode:
        if selectedCell != None:
            app.hoverCell = selectedCell
        else:
            app.hoverCell = None
        
        if app.selection != None:
            row, col = app.selection
            cellLeft, cellTop = getCellLeftTop(app, row, col)
            legals = getLegalsCell(app, mouseX, mouseY, cellLeft, cellTop)
            if legals != None and app.notes:
                app.hoverLegals = legals
            else:
                app.hoverLegals = None
            

        if selectedNumberKey != None:
            app.hoverNumberKey = selectedNumberKey
        else:
            app.hoverNumberKey = None

    if selectedLevel != None:
        app.hoverLevels = selectedLevel
    else:
        app.hoverLevels = None
    
    if selectedMode != None:
        app.hoverMode = selectedMode
    else:
        app.hoverMode = None

def loadBoardPaths(filters):
    boardPaths = [ ]
    for filename in os.listdir(f'tp-starter-files/boards/'):
        if filename.endswith('.txt'):
            if hasFilters(filename, filters):
                boardPaths.append(f'tp-starter-files/boards/{filename}')
    return boardPaths

def hasFilters(filename, filters=None):
    if filters == None: return True
    for filter in filters:
        if filter not in filename:
            return False
    return True

def loadRandomBoard(filters=None):
    return random.choice(loadBoardPaths(filters))

def createPDF(app):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font('Arial', 'B', 50)
    pdf.cell(210/2, 10, 'Board')
    pdf.image('boardImage.png',0,25,210,236)

    pdf.add_page()
    pdf.cell(210/2, 10, 'Solution')
    pdf.image('boardSolutionImage.png',0,25,210,236)
    filePath = app.loadBoard.split('/')
    fileName = filePath[-1]
    pdf.output(f"{fileName}.pdf", "F")
    print(f"{fileName}.pdf")

#From 112-3 Website sudoku writeup: https://www.cs.cmu.edu/~112-3/notes/tp-sudoku-hints.html
def readFile(path):
    with open(path, "rt") as f:
        return f.read()

def writeFile(path, contents):
    with open(path, "wt") as f:
        f.write(contents)