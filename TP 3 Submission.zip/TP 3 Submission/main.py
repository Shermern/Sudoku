try: from cmu_cs3_graphics import *
except: from cmu_graphics import *
from runAppWithScreens import *
from splashScreen import *
from helpScreen import *
from playScreen import *

# from https://www.cs.cmu.edu/~112-3/notes/runAppWithScreensDemo2.py
##################################
# main
##################################

def main():
    runAppWithScreens(initialScreen='splashScreen', width=1400, height=900)

main()