try: from cmu_cs3_graphics import *
except: from cmu_graphics import *

from runAppWithScreens import *

##################################
# Screen 2
##################################

def helpScreen_onScreenStart(app):
    app.howToPlayJpg = 'howToPlay.jpg'

def helpScreen_onKeyPress(app, key):
    if key == 'p': 
        setActiveScreen('playScreen')
    elif key == 's':
        setActiveScreen('splashScreen')

def helpScreen_redrawAll(app):
    imageWidth, imageHeight = 1188, 1066
    drawImage(app.howToPlayJpg, app.width/2, app.height/2, height=imageHeight*0.75, width= imageWidth*0.75, align='center')
